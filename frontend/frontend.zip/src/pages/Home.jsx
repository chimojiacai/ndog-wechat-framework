import { useState, useEffect } from "react";
import { Button, Space, Tag } from "antd";
import { System, Browser } from "@wailsio/runtime";
const Home = () => {
  const [osInfo, setOsInfo] = useState(null);

  useEffect(() => {
    const getOsInfo = async () => {
      const info = await System.Environment();
      setOsInfo(info);
    };
    getOsInfo();
  }, []);
  return (
    <div className="home">
      <div className="title-logo flex justify-center items-center !mb-5 !mt-32">
        <img src="../../public/logo.png" width="60" />
        <p className="text-4xl !ml-3 scbold">欢迎使用奶狗</p>
      </div>
      <div className="btns flex justify-center items-center !mb-5">
        <Space>
          <Button
            color="default"
            variant="solid"
            size="small"
            onClick={() => Browser.OpenURL("https://qm.qq.com/q/W1RCRfseAw")}
          >
            下载最新版本
          </Button>
          <Button
            color="default"
            variant="solid"
            size="small"
            onClick={() => Browser.OpenURL("https://qm.qq.com/q/W1RCRfseAw")}
          >
            官方QQ交流群
          </Button>
          <Button color="default" variant="solid" size="small">
            购买续费反馈
          </Button>
        </Space>
      </div>
      <div className="app-info text-center !mb-4.5">
        <Tag bordered={false}>{osInfo?.OSInfo.Branding}</Tag>
        <Tag bordered={false}>{osInfo?.OSInfo.ID}</Tag>
        <Tag bordered={false}>{osInfo?.OSInfo.Version}</Tag>
        <Tag bordered={false}>{osInfo?.PlatformInfo.WebView2}</Tag>
      </div>
      <div className="app-say text-center">
        <Tag bordered={false}>
          仅供学习测试、请勿直接用于商业用途、违法内容、生产环境等，与作者无关！
        </Tag>
      </div>
    </div>
  );
};

export default Home;
