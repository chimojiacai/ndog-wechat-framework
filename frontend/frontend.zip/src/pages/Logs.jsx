const Logs = () => {
  return (
    <div className="logs">
      <h1>日志</h1>
    </div>
  );
};

export default Logs;
