const My = () => {
  return (
    <div className="my">
      <h1>框架免费</h1>
    </div>
  );
};

export default My;
