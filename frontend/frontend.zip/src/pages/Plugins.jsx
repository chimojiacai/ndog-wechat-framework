const Plugins = () => {
  return (
    <div className="plugins">
      <h1>插件</h1>
    </div>
  );
};

export default Plugins;
