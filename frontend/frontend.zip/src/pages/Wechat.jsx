import { Card, Table, Tag, Space, Avatar, Tooltip, Button } from "antd";
import { UserOutlined } from "@ant-design/icons";
import { RunWechat } from "../../bindings/changeme/service/wechat/wechatservice";
import { msg } from "../hooks/useNotification";
const WechatList = () => {
  const columns = [
    {
      title: "头像",
      dataIndex: "avatarUrl",
      key: "avatarUrl",
      width: 80,
      align: "center",
      render: (avatarUrl) => (
        <Avatar shape="square" src={avatarUrl} icon={<UserOutlined />} />
      ),
    },
    {
      title: "昵称",
      dataIndex: "nick",
      key: "nick",
      width: 100,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "微信号",
      dataIndex: "wxNum",
      key: "wxNum",
      width: 100,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "微信ID",
      dataIndex: "wxid",
      key: "wxid",
      width: 100,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "端口",
      dataIndex: "port",
      key: "port",
      width: 80,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "进程",
      dataIndex: "pid",
      key: "pid",
      width: 80,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "到期",
      dataIndex: "expireTime",
      key: "expireTime",
      width: 100,
      align: "center",
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: "操作",
      key: "action",
      align: "center",
      fixed: "right",
      render: (_, record) => (
        <Space>
          {/* {record.wxid} */}
          <Button variant="solid" size="small">
            复制
          </Button>
          <Button color="danger" variant="solid" size="small">
            退出
          </Button>
        </Space>
      ),
    },
  ];
  const data = [
    {
      key: "1",
      avatarUrl: "",
      nick: "John Brown",
      wxNum: "coderYYQcoderYYQcoderYYQcoderYYQ",
      wxid: "wxid_nq6r0w9v12612",
      port: 7221,
      pid: 22612,
      expireTime: "2025-11-02 21:48:17",
    },
    {
      key: "2",
      avatarUrl:
        "https://wx.qlogo.cn/mmhead/ver_1/QnSVZHk9z1HiaUhGDjoHZZLPiaYXI9RlmSnAMiaepluzRFp2xUiapJBPbibVw1KictDUxQibyaJeXMjkh4WWsrJw1r65vsKiacydDPiaDsa5QXmzGZl6IKcU7vjylSWx0keb2VK9G/132",
      nick: "Jim Green",
      wxNum: "coderYYQ",
      wxid: "wxid_n240w9562612",
      port: 7221,
      pid: 22612,
      expireTime: "2025-11-02 21:48:17",
    },
    {
      key: "3",
      avatarUrl:
        "https://wx.qlogo.cn/mmhead/ver_1/QnSVZHk9z1HiaUhGDjoHZZLPiaYXI9RlmSnAMiaepluzRFp2xUiapJBPbibVw1KictDUxQibyaJeXMjkh4WWsrJw1r65vsKiacydDPiaDsa5QXmzGZl6IKcU7vjylSWx0keb2VK9G/132",
      nick: "Joe Black",
      wxNum: "coderYYQ",
      wxid: "wxid_nq65089v17612",
      port: 7221,
      pid: 22612,
      expireTime: "2025-11-02 21:48:17",
    },
  ];

  const loginWechat = async () => {
    try {
      const result = await RunWechat();
      if (result) {
        msg.success("微信启动成功！");
      }
    } catch (error) {
      msg.error("启动失败：" + error);
    }
  };
  return (
    <div className="h-full overflow-hidden flex flex-col" onClick={loginWechat}>
      <Table
        title={() => (
          <>
            <Button variant="solid" size="small" className="w-full">
              登录微信
            </Button>
            <Tag className="!mt-4">
              特别说明：框架内置多开插件，请先确保所有微信已关闭，需要开几个微信，就点击几次，“全部点击完成后再逐个登录微信账号”！
            </Tag>
          </>
        )}
        bordered
        columns={columns}
        dataSource={data}
        scroll={{ x: 840, y: "calc(100vh - 240px)" }}
        pagination={{ pageSize: 10 }}
        tableLayout="fixed"
      />
    </div>
  );
};

export default WechatList;
